fill ~-10 ~-3 ~-13 ~15 ~-2 ~12 minecraft:dirt
fill ~-10 ~-1 ~-13 ~15 ~-1 ~12 minecraft:grass_block[snowy=false]
