tellraw @s [{text:"[Mimas] ",color:"red"},{text:"Building...",color:"gold"}]
summon marker ~0.5 ~ ~0.5 {Tags:["mimas_origin"]}
# back up what is here now (in memory) so mimas:clear can put it back
setblock ~-10 ~31 ~-13 minecraft:structure_block[mode=save]{mode:"SAVE",name:"mimas:backup",author:"mimas",posX:0,posY:-34,posZ:0,sizeX:26,sizeY:34,sizeZ:26,ignoreEntities:1b,showboundingbox:0b,showair:0b}
setblock ~-10 ~32 ~-13 minecraft:redstone_block
setblock ~-10 ~32 ~-13 minecraft:air
setblock ~-10 ~31 ~-13 minecraft:air
fill ~-10 ~-3 ~-13 ~15 ~30 ~12 minecraft:air
function mimas:internal/blocks_1
function mimas:internal/blocks_2
function mimas:internal/blocks_3
execute positioned ~-10 ~-3 ~-13 run kill @e[type=item,dx=25,dy=33,dz=25]
tp @s ~0.5 ~ ~0.5 180 0
tellraw @s [{text:"[Mimas] ",color:"red"},{text:"Done. Undo with ",color:"gold"},{text:"/function mimas:clear",color:"yellow"}]
