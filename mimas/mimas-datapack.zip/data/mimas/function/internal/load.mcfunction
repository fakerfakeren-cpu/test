scoreboard objectives add mimas dummy
