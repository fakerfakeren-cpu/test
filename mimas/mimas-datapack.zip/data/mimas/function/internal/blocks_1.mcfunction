fill ~-10 ~-3 ~-13 ~15 ~-2 ~12 minecraft:stone
fill ~-10 ~-1 ~-13 ~10 ~4 ~-13 minecraft:quartz_bricks
fill ~11 ~-1 ~-13 ~15 ~4 ~-13 minecraft:smooth_sandstone
fill ~-10 ~-1 ~-12 ~-10 ~4 ~-4 minecraft:quartz_bricks
fill ~-9 ~-1 ~-12 ~9 ~-1 ~-10 minecraft:smooth_stone
fill ~10 ~-1 ~-12 ~10 ~4 ~-4 minecraft:quartz_bricks
fill ~11 ~-1 ~-12 ~14 ~-1 ~-8 minecraft:smooth_stone
fill ~15 ~-1 ~-12 ~15 ~4 ~-3 minecraft:smooth_sandstone
setblock ~-9 ~-1 ~-9 minecraft:polished_andesite
setblock ~-8 ~-1 ~-9 minecraft:polished_diorite
setblock ~-7 ~-1 ~-9 minecraft:polished_andesite
setblock ~-6 ~-1 ~-9 minecraft:polished_diorite
fill ~-5 ~-1 ~-9 ~9 ~-1 ~-8 minecraft:smooth_stone
setblock ~-9 ~-1 ~-8 minecraft:polished_diorite
setblock ~-8 ~-1 ~-8 minecraft:polished_andesite
setblock ~-7 ~-1 ~-8 minecraft:polished_diorite
setblock ~-6 ~-1 ~-8 minecraft:polished_andesite
setblock ~-9 ~-1 ~-7 minecraft:polished_andesite
setblock ~-8 ~-1 ~-7 minecraft:polished_diorite
setblock ~-7 ~-1 ~-7 minecraft:polished_andesite
setblock ~-6 ~-1 ~-7 minecraft:polished_diorite
setblock ~-5 ~-1 ~-7 minecraft:polished_andesite
setblock ~-4 ~-1 ~-7 minecraft:polished_diorite
setblock ~-3 ~-1 ~-7 minecraft:polished_andesite
setblock ~-2 ~-1 ~-7 minecraft:polished_diorite
setblock ~-1 ~-1 ~-7 minecraft:polished_andesite
setblock ~ ~-1 ~-7 minecraft:polished_diorite
setblock ~1 ~-1 ~-7 minecraft:polished_andesite
setblock ~2 ~-1 ~-7 minecraft:polished_diorite
setblock ~3 ~-1 ~-7 minecraft:polished_andesite
fill ~4 ~-1 ~-7 ~9 ~-1 ~-4 minecraft:smooth_stone
fill ~11 ~-1 ~-7 ~11 ~-1 ~-4 minecraft:smooth_stone
fill ~12 ~-1 ~-7 ~13 ~-1 ~-4 minecraft:polished_andesite
fill ~14 ~-1 ~-7 ~14 ~-1 ~-4 minecraft:smooth_stone
setblock ~-9 ~-1 ~-6 minecraft:polished_diorite
setblock ~-8 ~-1 ~-6 minecraft:polished_andesite
setblock ~-7 ~-1 ~-6 minecraft:polished_diorite
setblock ~-6 ~-1 ~-6 minecraft:polished_andesite
setblock ~-5 ~-1 ~-6 minecraft:polished_diorite
setblock ~-4 ~-1 ~-6 minecraft:polished_andesite
setblock ~-3 ~-1 ~-6 minecraft:polished_diorite
setblock ~-2 ~-1 ~-6 minecraft:polished_andesite
setblock ~-1 ~-1 ~-6 minecraft:polished_diorite
setblock ~ ~-1 ~-6 minecraft:polished_andesite
setblock ~1 ~-1 ~-6 minecraft:polished_diorite
setblock ~2 ~-1 ~-6 minecraft:polished_andesite
setblock ~3 ~-1 ~-6 minecraft:polished_diorite
setblock ~-9 ~-1 ~-5 minecraft:polished_andesite
setblock ~-8 ~-1 ~-5 minecraft:polished_diorite
setblock ~-7 ~-1 ~-5 minecraft:polished_andesite
setblock ~-6 ~-1 ~-5 minecraft:polished_diorite
setblock ~-5 ~-1 ~-5 minecraft:polished_andesite
setblock ~-4 ~-1 ~-5 minecraft:polished_diorite
setblock ~-3 ~-1 ~-5 minecraft:polished_andesite
setblock ~-2 ~-1 ~-5 minecraft:polished_diorite
setblock ~-1 ~-1 ~-5 minecraft:polished_andesite
setblock ~ ~-1 ~-5 minecraft:polished_diorite
setblock ~1 ~-1 ~-5 minecraft:polished_andesite
setblock ~2 ~-1 ~-5 minecraft:polished_diorite
setblock ~3 ~-1 ~-5 minecraft:polished_andesite
setblock ~-9 ~-1 ~-4 minecraft:polished_diorite
setblock ~-8 ~-1 ~-4 minecraft:polished_andesite
setblock ~-7 ~-1 ~-4 minecraft:polished_diorite
setblock ~-6 ~-1 ~-4 minecraft:polished_andesite
setblock ~-5 ~-1 ~-4 minecraft:polished_diorite
setblock ~-4 ~-1 ~-4 minecraft:polished_andesite
setblock ~-3 ~-1 ~-4 minecraft:polished_diorite
setblock ~-2 ~-1 ~-4 minecraft:polished_andesite
setblock ~-1 ~-1 ~-4 minecraft:polished_diorite
setblock ~ ~-1 ~-4 minecraft:polished_andesite
setblock ~1 ~-1 ~-4 minecraft:polished_diorite
setblock ~2 ~-1 ~-4 minecraft:polished_andesite
setblock ~3 ~-1 ~-4 minecraft:polished_diorite
fill ~-10 ~-1 ~-3 ~-10 ~4 ~-3 minecraft:polished_deepslate
fill ~-9 ~-1 ~-3 ~3 ~-1 ~-3 minecraft:smooth_stone
fill ~4 ~-1 ~-3 ~4 ~4 ~-3 minecraft:polished_deepslate
fill ~5 ~-1 ~-3 ~9 ~-1 ~-3 minecraft:smooth_stone
fill ~10 ~-1 ~-3 ~10 ~4 ~-3 minecraft:polished_deepslate
fill ~11 ~-1 ~-3 ~14 ~-1 ~-3 minecraft:stone_bricks
fill ~-10 ~-1 ~-2 ~-9 ~-1 ~-2 minecraft:polished_andesite
fill ~-8 ~-1 ~-2 ~-7 ~-1 ~-2 minecraft:smooth_stone
fill ~-6 ~-1 ~-2 ~-5 ~-1 ~-2 minecraft:polished_andesite
fill ~-4 ~-1 ~-2 ~-3 ~-1 ~-2 minecraft:smooth_stone
fill ~-2 ~-1 ~-2 ~-1 ~-1 ~-2 minecraft:polished_andesite
fill ~ ~-1 ~-2 ~1 ~-1 ~-2 minecraft:smooth_stone
fill ~2 ~-1 ~-2 ~3 ~-1 ~-2 minecraft:polished_andesite
fill ~4 ~-1 ~-2 ~5 ~-1 ~-2 minecraft:smooth_stone
fill ~6 ~-1 ~-2 ~7 ~-1 ~-2 minecraft:polished_andesite
fill ~8 ~-1 ~-2 ~9 ~-1 ~-2 minecraft:smooth_stone
fill ~10 ~-1 ~-2 ~11 ~-1 ~-2 minecraft:polished_andesite
fill ~12 ~-1 ~-2 ~13 ~-1 ~-2 minecraft:smooth_stone
fill ~14 ~-1 ~-2 ~15 ~-1 ~-2 minecraft:polished_andesite
fill ~-10 ~-1 ~-1 ~-9 ~-1 ~ minecraft:smooth_stone
fill ~-8 ~-1 ~-1 ~-7 ~-1 ~ minecraft:polished_andesite
fill ~-6 ~-1 ~-1 ~-5 ~-1 ~ minecraft:smooth_stone
fill ~-4 ~-1 ~-1 ~-3 ~-1 ~ minecraft:polished_andesite
fill ~-2 ~-1 ~-1 ~-1 ~-1 ~ minecraft:smooth_stone
fill ~ ~-1 ~-1 ~1 ~-1 ~ minecraft:polished_andesite
fill ~2 ~-1 ~-1 ~3 ~-1 ~ minecraft:smooth_stone
fill ~4 ~-1 ~-1 ~5 ~-1 ~ minecraft:polished_andesite
fill ~6 ~-1 ~-1 ~7 ~-1 ~ minecraft:smooth_stone
fill ~8 ~-1 ~-1 ~9 ~-1 ~ minecraft:polished_andesite
fill ~10 ~-1 ~-1 ~11 ~-1 ~ minecraft:smooth_stone
fill ~12 ~-1 ~-1 ~13 ~-1 ~ minecraft:polished_andesite
fill ~14 ~-1 ~-1 ~15 ~-1 ~ minecraft:smooth_stone
fill ~-10 ~-1 ~1 ~-9 ~-1 ~2 minecraft:polished_andesite
fill ~-8 ~-1 ~1 ~-7 ~-1 ~1 minecraft:smooth_stone
fill ~-6 ~-1 ~1 ~-5 ~-1 ~2 minecraft:polished_andesite
fill ~-4 ~-1 ~1 ~-3 ~-1 ~1 minecraft:smooth_stone
fill ~-2 ~-1 ~1 ~-1 ~-1 ~2 minecraft:polished_andesite
fill ~ ~-1 ~1 ~1 ~-1 ~1 minecraft:smooth_stone
fill ~2 ~-1 ~1 ~3 ~-1 ~2 minecraft:polished_andesite
fill ~4 ~-1 ~1 ~5 ~-1 ~1 minecraft:smooth_stone
fill ~6 ~-1 ~1 ~7 ~-1 ~2 minecraft:polished_andesite
fill ~8 ~-1 ~1 ~9 ~-1 ~1 minecraft:smooth_stone
fill ~10 ~-1 ~1 ~11 ~-1 ~2 minecraft:polished_andesite
fill ~12 ~-1 ~1 ~13 ~-1 ~1 minecraft:smooth_stone
fill ~14 ~-1 ~1 ~15 ~-1 ~2 minecraft:polished_andesite
fill ~-8 ~-1 ~2 ~-7 ~-1 ~2 minecraft:polished_andesite
fill ~-4 ~-1 ~2 ~-3 ~-1 ~2 minecraft:polished_andesite
fill ~ ~-1 ~2 ~1 ~-1 ~2 minecraft:polished_andesite
fill ~4 ~-1 ~2 ~5 ~-1 ~2 minecraft:polished_andesite
fill ~8 ~-1 ~2 ~9 ~-1 ~2 minecraft:polished_andesite
fill ~12 ~-1 ~2 ~13 ~-1 ~2 minecraft:polished_andesite
fill ~-10 ~-1 ~3 ~15 ~-1 ~3 minecraft:gray_concrete
fill ~-10 ~-1 ~4 ~10 ~-1 ~4 minecraft:gray_concrete
fill ~11 ~-1 ~4 ~14 ~-1 ~4 minecraft:white_concrete
setblock ~15 ~-1 ~4 minecraft:gray_concrete
fill ~-10 ~-1 ~5 ~15 ~-1 ~5 minecraft:polished_andesite
fill ~-10 ~-1 ~6 ~10 ~-1 ~6 minecraft:gray_concrete
fill ~11 ~-1 ~6 ~14 ~-1 ~6 minecraft:white_concrete
setblock ~15 ~-1 ~6 minecraft:gray_concrete
fill ~-10 ~-1 ~7 ~15 ~-1 ~7 minecraft:polished_andesite
fill ~-10 ~-1 ~8 ~10 ~-1 ~9 minecraft:gray_concrete
fill ~11 ~-1 ~8 ~14 ~-1 ~8 minecraft:white_concrete
fill ~15 ~-1 ~8 ~15 ~-1 ~9 minecraft:gray_concrete
fill ~11 ~-1 ~9 ~14 ~-1 ~9 minecraft:gray_concrete
fill ~-10 ~-1 ~10 ~15 ~-1 ~10 minecraft:polished_andesite
fill ~-10 ~-1 ~11 ~-9 ~-1 ~12 minecraft:smooth_stone
fill ~-8 ~-1 ~11 ~-7 ~-1 ~12 minecraft:polished_andesite
fill ~-6 ~-1 ~11 ~-5 ~-1 ~12 minecraft:smooth_stone
fill ~-4 ~-1 ~11 ~-3 ~-1 ~12 minecraft:polished_andesite
fill ~-2 ~-1 ~11 ~-1 ~-1 ~12 minecraft:smooth_stone
fill ~ ~-1 ~11 ~1 ~-1 ~12 minecraft:polished_andesite
fill ~2 ~-1 ~11 ~3 ~-1 ~12 minecraft:smooth_stone
fill ~4 ~-1 ~11 ~5 ~-1 ~12 minecraft:polished_andesite
fill ~6 ~-1 ~11 ~7 ~-1 ~12 minecraft:smooth_stone
fill ~8 ~-1 ~11 ~9 ~-1 ~12 minecraft:polished_andesite
fill ~10 ~-1 ~11 ~11 ~-1 ~12 minecraft:smooth_stone
fill ~12 ~-1 ~11 ~13 ~-1 ~12 minecraft:polished_andesite
fill ~14 ~-1 ~11 ~15 ~-1 ~12 minecraft:smooth_stone
setblock ~1 ~ ~-12 minecraft:smoker[facing=south,lit=false]
setblock ~2 ~ ~-12 minecraft:iron_block
fill ~3 ~ ~-12 ~4 ~ ~-12 minecraft:white_concrete
setblock ~5 ~ ~-12 minecraft:composter[level=0]
fill ~7 ~ ~-12 ~8 ~1 ~-12 minecraft:barrel[facing=up,open=false]
setblock ~9 ~ ~-12 minecraft:cauldron
fill ~-9 ~ ~-11 ~-8 ~ ~-11 minecraft:barrel[facing=up,open=false]
setblock ~-7 ~ ~-11 minecraft:chest[facing=north,type=single,waterlogged=false]
fill ~-6 ~ ~-11 ~-5 ~ ~-11 minecraft:water_cauldron[level=3]
setblock ~-4 ~ ~-11 minecraft:iron_block
fill ~-3 ~ ~-11 ~-3 ~2 ~-11 minecraft:white_concrete
setblock ~-2 ~ ~-11 minecraft:furnace[facing=north,lit=false]
fill ~-1 ~ ~-11 ~-1 ~2 ~-11 minecraft:barrel[facing=north,open=false]
fill ~-9 ~ ~-10 ~-4 ~4 ~-10 minecraft:quartz_bricks
fill ~-3 ~ ~-10 ~-3 ~2 ~-10 minecraft:magma_block
fill ~-2 ~ ~-10 ~-2 ~4 ~-10 minecraft:quartz_bricks
fill ~-1 ~ ~-10 ~-1 ~2 ~-10 minecraft:magma_block
fill ~ ~ ~-10 ~5 ~4 ~-10 minecraft:quartz_bricks
fill ~7 ~ ~-10 ~9 ~4 ~-10 minecraft:quartz_bricks
fill ~-5 ~ ~-9 ~-5 ~4 ~-8 minecraft:quartz_bricks
setblock ~-4 ~ ~-9 minecraft:iron_block
setblock ~-3 ~ ~-9 minecraft:cauldron
setblock ~-2 ~ ~-9 minecraft:iron_block
setblock ~-1 ~ ~-9 minecraft:cauldron
setblock ~ ~ ~-9 minecraft:iron_block
setblock ~1 ~ ~-9 minecraft:smoker[facing=south,lit=true]
fill ~2 ~ ~-9 ~3 ~ ~-9 minecraft:cauldron
fill ~4 ~ ~-9 ~5 ~ ~-9 minecraft:iron_block
fill ~7 ~ ~-9 ~8 ~ ~-9 minecraft:iron_block
fill ~9 ~ ~-9 ~9 ~1 ~-9 minecraft:barrel[facing=up,open=false]
fill ~11 ~ ~-8 ~14 ~4 ~-8 minecraft:smooth_sandstone
setblock ~-4 ~ ~-7 minecraft:red_concrete
fill ~3 ~ ~-7 ~4 ~ ~-7 minecraft:red_concrete
fill ~9 ~ ~-7 ~9 ~ ~-5 minecraft:iron_block
fill ~11 ~ ~-7 ~11 ~4 ~-4 minecraft:smooth_sandstone
fill ~14 ~ ~-7 ~14 ~4 ~-4 minecraft:smooth_sandstone
setblock ~4 ~ ~-6 minecraft:light_blue_stained_glass
setblock ~4 ~ ~-4 minecraft:lime_stained_glass
fill ~5 ~ ~-4 ~8 ~ ~-4 minecraft:iron_block
setblock ~9 ~ ~-4 minecraft:barrel[facing=up,open=false]
fill ~5 ~ ~-3 ~8 ~ ~-3 minecraft:polished_deepslate
fill ~11 ~ ~-3 ~11 ~4 ~-3 minecraft:stone_bricks
fill ~14 ~ ~-3 ~14 ~4 ~-3 minecraft:stone_bricks
setblock ~6 ~ ~1 minecraft:cauldron
fill ~-8 ~ ~12 ~-8 ~2 ~12 minecraft:oak_log[axis=y]
fill ~13 ~ ~12 ~13 ~2 ~12 minecraft:oak_log[axis=y]
setblock ~-9 ~1 ~-11 minecraft:barrel[facing=up,open=false]
fill ~-3 ~1 ~-9 ~-3 ~2 ~-9 minecraft:stripped_oak_log[axis=y]
fill ~-1 ~1 ~-9 ~-1 ~2 ~-9 minecraft:stripped_dark_oak_log[axis=y]
setblock ~7 ~1 ~-9 minecraft:decorated_pot[cracked=false,facing=south]
setblock ~4 ~1 ~-6 minecraft:orange_stained_glass
setblock ~4 ~1 ~-4 minecraft:yellow_stained_glass
setblock ~12 ~2 ~-11 minecraft:light[level=15,waterlogged=false]
fill ~6 ~2 ~-10 ~6 ~4 ~-10 minecraft:quartz_bricks
setblock ~4 ~2 ~-6 minecraft:red_stained_glass
setblock ~4 ~2 ~-4 minecraft:red_stained_glass
fill ~-3 ~3 ~-10 ~-3 ~4 ~-10 minecraft:quartz_bricks
fill ~-1 ~3 ~-10 ~-1 ~4 ~-10 minecraft:quartz_bricks
setblock ~4 ~3 ~-6 minecraft:sea_lantern
setblock ~4 ~3 ~-4 minecraft:sea_lantern
fill ~-9 ~4 ~-3 ~3 ~4 ~-3 minecraft:polished_deepslate
fill ~5 ~4 ~-3 ~9 ~4 ~-3 minecraft:polished_deepslate
fill ~12 ~4 ~-3 ~13 ~4 ~-3 minecraft:stone_bricks
fill ~-10 ~4 ~-2 ~15 ~4 ~-2 minecraft:polished_blackstone
fill ~-10 ~5 ~-13 ~15 ~5 ~-12 minecraft:smooth_quartz
fill ~-10 ~5 ~-11 ~-8 ~5 ~-3 minecraft:smooth_quartz
setblock ~-7 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~-6 ~5 ~-11 ~-5 ~5 ~-3 minecraft:smooth_quartz
setblock ~-4 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~-3 ~5 ~-11 ~-2 ~5 ~-3 minecraft:smooth_quartz
setblock ~-1 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~ ~5 ~-11 ~1 ~5 ~-3 minecraft:smooth_quartz
setblock ~2 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~3 ~5 ~-11 ~4 ~5 ~-3 minecraft:smooth_quartz
setblock ~5 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~6 ~5 ~-11 ~7 ~5 ~-3 minecraft:smooth_quartz
setblock ~8 ~5 ~-11 minecraft:pearlescent_froglight[axis=y]
fill ~9 ~5 ~-11 ~15 ~5 ~-3 minecraft:smooth_quartz
fill ~-7 ~5 ~-10 ~-7 ~5 ~-9 minecraft:smooth_quartz
fill ~-4 ~5 ~-10 ~-4 ~5 ~-9 minecraft:smooth_quartz
fill ~-1 ~5 ~-10 ~-1 ~5 ~-9 minecraft:smooth_quartz
fill ~2 ~5 ~-10 ~2 ~5 ~-9 minecraft:smooth_quartz
fill ~5 ~5 ~-10 ~5 ~5 ~-9 minecraft:smooth_quartz
fill ~8 ~5 ~-10 ~8 ~5 ~-9 minecraft:smooth_quartz
setblock ~-7 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
setblock ~-4 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
setblock ~-1 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
setblock ~2 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
setblock ~5 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
setblock ~8 ~5 ~-8 minecraft:pearlescent_froglight[axis=y]
fill ~-7 ~5 ~-7 ~-7 ~5 ~-6 minecraft:smooth_quartz
fill ~-4 ~5 ~-7 ~-4 ~5 ~-6 minecraft:smooth_quartz
fill ~-1 ~5 ~-7 ~-1 ~5 ~-6 minecraft:smooth_quartz
fill ~2 ~5 ~-7 ~2 ~5 ~-6 minecraft:smooth_quartz
fill ~5 ~5 ~-7 ~5 ~5 ~-6 minecraft:smooth_quartz
fill ~8 ~5 ~-7 ~8 ~5 ~-6 minecraft:smooth_quartz
setblock ~-7 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
setblock ~-4 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
setblock ~-1 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
setblock ~2 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
setblock ~5 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
setblock ~8 ~5 ~-5 minecraft:pearlescent_froglight[axis=y]
fill ~-7 ~5 ~-4 ~-7 ~5 ~-3 minecraft:smooth_quartz
fill ~-4 ~5 ~-4 ~-4 ~5 ~-3 minecraft:smooth_quartz
fill ~-1 ~5 ~-4 ~-1 ~5 ~-3 minecraft:smooth_quartz
fill ~2 ~5 ~-4 ~2 ~5 ~-3 minecraft:smooth_quartz
fill ~5 ~5 ~-4 ~5 ~5 ~-3 minecraft:smooth_quartz
fill ~8 ~5 ~-4 ~8 ~5 ~-3 minecraft:smooth_quartz
fill ~-10 ~5 ~-2 ~-10 ~10 ~-2 minecraft:polished_blackstone
fill ~-9 ~5 ~-2 ~-9 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-8 ~5 ~-2 ~-6 ~6 ~-2 minecraft:red_concrete
fill ~-5 ~5 ~-2 ~-5 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-4 ~5 ~-2 ~-4 ~9 ~-2 minecraft:red_concrete
fill ~-3 ~5 ~-2 ~-3 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-2 ~5 ~-2 ~-1 ~5 ~-2 minecraft:red_concrete
fill ~ ~5 ~-2 ~ ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~1 ~5 ~-2 ~1 ~9 ~-2 minecraft:red_concrete
fill ~2 ~5 ~-2 ~2 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~3 ~5 ~-2 ~5 ~6 ~-2 minecraft:red_concrete
fill ~6 ~5 ~-2 ~6 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~7 ~5 ~-2 ~7 ~9 ~-2 minecraft:red_concrete
fill ~8 ~5 ~-2 ~8 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~9 ~5 ~-2 ~9 ~6 ~-2 minecraft:red_concrete
fill ~10 ~5 ~-2 ~10 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~11 ~5 ~-2 ~12 ~5 ~-2 minecraft:red_concrete
fill ~13 ~5 ~-2 ~14 ~5 ~-2 minecraft:ochre_froglight[axis=y]
fill ~15 ~5 ~-2 ~15 ~10 ~-2 minecraft:polished_blackstone
fill ~-10 ~6 ~-13 ~15 ~23 ~-13 minecraft:smooth_sandstone
fill ~-10 ~6 ~-12 ~-10 ~10 ~-3 minecraft:smooth_sandstone
fill ~15 ~6 ~-12 ~15 ~10 ~-3 minecraft:smooth_sandstone
fill ~-9 ~6 ~-3 ~14 ~10 ~-3 minecraft:smooth_sandstone
setblock ~-2 ~6 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~-1 ~6 ~-2 minecraft:red_concrete
fill ~11 ~6 ~-2 ~11 ~9 ~-2 minecraft:red_concrete
fill ~12 ~6 ~-2 ~12 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~13 ~6 ~-2 ~14 ~8 ~-2 minecraft:red_concrete
setblock ~-4 ~7 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~9 ~7 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~-8 ~7 ~-2 minecraft:red_concrete
setblock ~-7 ~7 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~-6 ~7 ~-2 minecraft:red_concrete
fill ~-2 ~7 ~-2 ~-2 ~9 ~-2 minecraft:red_concrete
setblock ~-1 ~7 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~3 ~7 ~-2 minecraft:red_concrete
setblock ~4 ~7 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~5 ~7 ~-2 minecraft:red_concrete
setblock ~9 ~7 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~-8 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-7 ~8 ~-2 ~-7 ~9 ~-2 minecraft:red_concrete
setblock ~-6 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-1 ~8 ~-2 ~-1 ~9 ~-2 minecraft:red_concrete
setblock ~3 ~8 ~-2 minecraft:ochre_froglight[axis=y]
fill ~4 ~8 ~-2 ~4 ~9 ~-2 minecraft:red_concrete
setblock ~5 ~8 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~9 ~8 ~-2 minecraft:red_concrete
setblock ~-8 ~9 ~-2 minecraft:red_concrete
setblock ~-6 ~9 ~-2 minecraft:red_concrete
setblock ~3 ~9 ~-2 minecraft:red_concrete
setblock ~5 ~9 ~-2 minecraft:red_concrete
setblock ~8 ~9 ~-2 minecraft:red_concrete
setblock ~9 ~9 ~-2 minecraft:ochre_froglight[axis=y]
setblock ~10 ~9 ~-2 minecraft:red_concrete
setblock ~12 ~9 ~-2 minecraft:red_concrete
fill ~13 ~9 ~-2 ~14 ~9 ~-2 minecraft:ochre_froglight[axis=y]
fill ~-9 ~10 ~-2 ~14 ~10 ~-2 minecraft:polished_blackstone
fill ~-10 ~11 ~-12 ~-10 ~24 ~-4 minecraft:smooth_sandstone
fill ~-9 ~11 ~-12 ~14 ~11 ~-4 minecraft:spruce_planks
fill ~15 ~11 ~-12 ~15 ~24 ~-4 minecraft:smooth_sandstone
fill ~-10 ~11 ~-3 ~15 ~11 ~-3 minecraft:smooth_quartz
fill ~-10 ~12 ~-3 ~-9 ~13 ~-3 minecraft:smooth_sandstone
fill ~-6 ~12 ~-3 ~-5 ~13 ~-3 minecraft:smooth_sandstone
fill ~-2 ~12 ~-3 ~-1 ~13 ~-3 minecraft:smooth_sandstone
fill ~2 ~12 ~-3 ~3 ~13 ~-3 minecraft:smooth_sandstone
fill ~6 ~12 ~-3 ~7 ~13 ~-3 minecraft:smooth_sandstone
fill ~10 ~12 ~-3 ~11 ~13 ~-3 minecraft:smooth_sandstone
fill ~14 ~12 ~-3 ~15 ~13 ~-3 minecraft:smooth_sandstone
setblock ~2 ~12 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~14 ~12 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~-4 ~13 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~9 ~13 ~-8 minecraft:light[level=15,waterlogged=false]
fill ~-9 ~14 ~-12 ~14 ~14 ~-4 minecraft:spruce_planks
fill ~-10 ~14 ~-3 ~15 ~14 ~-3 minecraft:smooth_quartz
fill ~-10 ~15 ~-3 ~-9 ~16 ~-3 minecraft:smooth_sandstone
fill ~-6 ~15 ~-3 ~-5 ~16 ~-3 minecraft:smooth_sandstone
fill ~-2 ~15 ~-3 ~-1 ~16 ~-3 minecraft:smooth_sandstone
fill ~2 ~15 ~-3 ~3 ~16 ~-3 minecraft:smooth_sandstone
fill ~6 ~15 ~-3 ~7 ~16 ~-3 minecraft:smooth_sandstone
fill ~10 ~15 ~-3 ~11 ~16 ~-3 minecraft:smooth_sandstone
fill ~14 ~15 ~-3 ~15 ~16 ~-3 minecraft:smooth_sandstone
setblock ~-6 ~15 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~-4 ~16 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~9 ~16 ~-8 minecraft:light[level=15,waterlogged=false]
fill ~-9 ~17 ~-12 ~14 ~17 ~-4 minecraft:spruce_planks
fill ~-10 ~17 ~-3 ~15 ~17 ~-3 minecraft:smooth_quartz
fill ~-10 ~18 ~-3 ~-9 ~19 ~-3 minecraft:smooth_sandstone
fill ~-6 ~18 ~-3 ~-5 ~19 ~-3 minecraft:smooth_sandstone
fill ~-2 ~18 ~-3 ~-1 ~19 ~-3 minecraft:smooth_sandstone
fill ~2 ~18 ~-3 ~3 ~19 ~-3 minecraft:smooth_sandstone
fill ~6 ~18 ~-3 ~7 ~19 ~-3 minecraft:smooth_sandstone
fill ~10 ~18 ~-3 ~11 ~19 ~-3 minecraft:smooth_sandstone
fill ~14 ~18 ~-3 ~15 ~19 ~-3 minecraft:smooth_sandstone
setblock ~-1 ~18 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~11 ~18 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~-4 ~19 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~9 ~19 ~-8 minecraft:light[level=15,waterlogged=false]
fill ~-9 ~20 ~-12 ~14 ~20 ~-4 minecraft:spruce_planks
fill ~-10 ~20 ~-3 ~15 ~20 ~-3 minecraft:smooth_quartz
fill ~-10 ~21 ~-3 ~-9 ~23 ~-3 minecraft:smooth_sandstone
fill ~-6 ~21 ~-3 ~-5 ~23 ~-3 minecraft:smooth_sandstone
fill ~-2 ~21 ~-3 ~-1 ~23 ~-3 minecraft:smooth_sandstone
fill ~2 ~21 ~-3 ~3 ~23 ~-3 minecraft:smooth_sandstone
fill ~6 ~21 ~-3 ~7 ~23 ~-3 minecraft:smooth_sandstone
fill ~10 ~21 ~-3 ~11 ~23 ~-3 minecraft:smooth_sandstone
fill ~14 ~21 ~-3 ~15 ~23 ~-3 minecraft:smooth_sandstone
setblock ~3 ~21 ~-2 minecraft:white_glazed_terracotta[facing=south]
setblock ~-4 ~22 ~-8 minecraft:light[level=15,waterlogged=false]
setblock ~9 ~22 ~-8 minecraft:light[level=15,waterlogged=false]
fill ~-9 ~23 ~-12 ~14 ~23 ~-4 minecraft:smooth_sandstone
fill ~-8 ~23 ~-3 ~-7 ~23 ~-3 minecraft:smooth_sandstone
fill ~-4 ~23 ~-3 ~-3 ~23 ~-3 minecraft:smooth_sandstone
fill ~ ~23 ~-3 ~1 ~23 ~-3 minecraft:smooth_sandstone
fill ~4 ~23 ~-3 ~5 ~23 ~-3 minecraft:smooth_sandstone
fill ~8 ~23 ~-3 ~9 ~23 ~-3 minecraft:smooth_sandstone
fill ~12 ~23 ~-3 ~13 ~23 ~-3 minecraft:smooth_sandstone
fill ~-4 ~24 ~-10 ~-4 ~30 ~-10 minecraft:bricks
fill ~9 ~24 ~-10 ~9 ~30 ~-10 minecraft:bricks
setblock ~-10 ~24 ~-3 minecraft:smooth_sandstone
setblock ~15 ~24 ~-3 minecraft:smooth_sandstone
fill ~-10 ~25 ~-11 ~-10 ~25 ~-4 minecraft:smooth_sandstone
fill ~15 ~25 ~-11 ~15 ~25 ~-4 minecraft:smooth_sandstone
setblock ~2 ~25 ~-8 minecraft:light[level=15,waterlogged=false]
fill ~-10 ~26 ~-10 ~-10 ~26 ~-5 minecraft:smooth_sandstone
fill ~15 ~26 ~-10 ~15 ~26 ~-5 minecraft:smooth_sandstone
fill ~-10 ~27 ~-9 ~-10 ~27 ~-6 minecraft:smooth_sandstone
fill ~15 ~27 ~-9 ~15 ~27 ~-6 minecraft:smooth_sandstone
fill ~-10 ~28 ~-8 ~-10 ~28 ~-7 minecraft:smooth_sandstone
fill ~15 ~28 ~-8 ~15 ~28 ~-7 minecraft:smooth_sandstone
