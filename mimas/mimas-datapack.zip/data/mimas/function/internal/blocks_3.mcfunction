setblock ~6 ~ ~-10 minecraft:dark_oak_door[facing=south,half=lower,hinge=left,open=false,powered=false]
setblock ~-3 ~ ~-7 minecraft:red_concrete_powder
setblock ~-2 ~ ~-7 minecraft:lime_concrete_powder
setblock ~-1 ~ ~-7 minecraft:white_concrete_powder
setblock ~ ~ ~-7 minecraft:purple_concrete_powder
setblock ~1 ~ ~-7 minecraft:yellow_concrete_powder
setblock ~2 ~ ~-7 minecraft:orange_concrete_powder
setblock ~-9 ~ ~-4 minecraft:potted_bamboo
fill ~-7 ~ ~-4 ~-6 ~ ~-4 minecraft:polished_blackstone_pressure_plate[powered=false]
setblock ~-7 ~ ~-3 minecraft:iron_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock ~-6 ~ ~-3 minecraft:iron_door[facing=north,half=lower,hinge=right,open=false,powered=false]
setblock ~12 ~ ~-3 minecraft:spruce_door[facing=north,half=lower,hinge=left,open=false,powered=false]
setblock ~13 ~ ~-3 minecraft:spruce_door[facing=north,half=lower,hinge=right,open=false,powered=false]
fill ~-7 ~ ~-2 ~-6 ~ ~-2 minecraft:polished_blackstone_pressure_plate[powered=false]
fill ~-10 ~ ~5 ~15 ~ ~5 minecraft:rail[shape=east_west,waterlogged=false]
fill ~-10 ~ ~7 ~15 ~ ~7 minecraft:rail[shape=east_west,waterlogged=false]
setblock ~2 ~1 ~-12 minecraft:white_candle[candles=3,lit=false]
setblock ~-4 ~1 ~-11 minecraft:oak_pressure_plate[powered=false]
setblock ~6 ~1 ~-10 minecraft:dark_oak_door[facing=south,half=upper,hinge=left,open=false,powered=false]
setblock ~-8 ~1 ~-9 minecraft:birch_pressure_plate[powered=false]
setblock ~-4 ~1 ~-9 minecraft:white_candle[candles=3,lit=false]
setblock ~-2 ~1 ~-9 minecraft:red_candle[candles=2,lit=false]
setblock ~ ~1 ~-9 minecraft:yellow_candle[candles=2,lit=false]
setblock ~1 ~1 ~-9 minecraft:heavy_weighted_pressure_plate[power=0]
setblock ~4 ~1 ~-9 minecraft:stonecutter[facing=south]
setblock ~5 ~1 ~-9 minecraft:oak_pressure_plate[powered=false]
setblock ~-8 ~1 ~-7 minecraft:birch_pressure_plate[powered=false]
setblock ~-4 ~1 ~-7 minecraft:daylight_detector[inverted=false]
setblock ~9 ~1 ~-6 minecraft:white_candle[candles=4,lit=false]
setblock ~-4 ~1 ~-5 minecraft:spruce_pressure_plate[powered=false]
setblock ~-2 ~1 ~-5 minecraft:spruce_pressure_plate[powered=false]
setblock ~ ~1 ~-5 minecraft:spruce_pressure_plate[powered=false]
setblock ~2 ~1 ~-5 minecraft:spruce_pressure_plate[powered=false]
setblock ~6 ~1 ~-4 minecraft:daylight_detector[inverted=false]
setblock ~-7 ~1 ~-3 minecraft:iron_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock ~-6 ~1 ~-3 minecraft:iron_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock ~12 ~1 ~-3 minecraft:spruce_door[facing=north,half=upper,hinge=left,open=false,powered=false]
setblock ~13 ~1 ~-3 minecraft:spruce_door[facing=north,half=upper,hinge=right,open=false,powered=false]
setblock ~14 ~1 ~-2 minecraft:stone_button[face=wall,facing=south,powered=false]
setblock ~-1 ~1 ~-1 minecraft:heavy_weighted_pressure_plate[power=0]
setblock ~2 ~1 ~-1 minecraft:heavy_weighted_pressure_plate[power=0]
setblock ~-8 ~4 ~-9 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~-8 ~4 ~-7 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~-4 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ПИЛЕШКИ","ДЮНЕР","среден","5,50 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~-3 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ПИЛЕШКИ","ДЮНЕР","XL","8,60 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~-2 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ТЕЛЕШКИ","ДЮНЕР","среден","7,44 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~-1 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ШИШ ТАУК","сандвич","двоен","7,41 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~ ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ФАЛАФЕЛ","сандвич","среден","3,83 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~1 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ФАЛАФЕЛ","сандвич","голям","4,35 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~2 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["ФАЛАФЕЛ","порция","10 бр.","5,62 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~3 ~4 ~-7 minecraft:dark_oak_hanging_sign[attached=false,rotation=0,waterlogged=false]{front_text:{color:"yellow",has_glowing_text:1b,messages:["МИМАС","МЕНЮ","+ картофи","10,73 €"]},back_text:{color:"yellow",has_glowing_text:1b,messages:["","","",""]},is_waxed:1b}
setblock ~12 ~4 ~-6 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~-3 ~4 ~-4 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~ ~4 ~-4 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~3 ~4 ~-4 minecraft:lantern[hanging=true,waterlogged=false]
setblock ~1 ~6 ~1 minecraft:lantern[hanging=false,waterlogged=false]
setblock ~1 ~6 ~11 minecraft:lantern[hanging=false,waterlogged=false]
setblock ~-3 ~12 ~-2 minecraft:potted_fern
setblock ~-3 ~15 ~-2 minecraft:potted_red_tulip
setblock ~-3 ~18 ~-2 minecraft:potted_fern
setblock ~-3 ~21 ~-2 minecraft:potted_red_tulip
