fill ~-10 ~-3 ~-13 ~15 ~30 ~12 minecraft:air
scoreboard players set #restored mimas 0
execute store success score #restored mimas run place template mimas:backup ~-10 ~-3 ~-13
execute if score #restored mimas matches 0 run function mimas:internal/flatten
execute positioned ~-10 ~-3 ~-13 run kill @e[type=item,dx=25,dy=33,dz=25]
execute if score #restored mimas matches 1 run tellraw @a[distance=..64] [{text:"[Mimas] ",color:"red"},{text:"Removed - original terrain restored.",color:"gold"}]
execute if score #restored mimas matches 0 run tellraw @a[distance=..64] [{text:"[Mimas] ",color:"red"},{text:"Removed. No backup in memory (world was reloaded), so the area was levelled to grass.",color:"gold"}]
kill @s
