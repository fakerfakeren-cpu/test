# Builds Mimas around you. You end up on the sidewalk in front of the shop, facing it (north).
# Footprint: 26 wide (x) x 26 deep (z) x 34 high, from 10 blocks west to 15 east, 13 north to 12 south.
execute if entity @e[type=marker,tag=mimas_origin,distance=..80] run function mimas:clear
execute align xyz run function mimas:internal/build_here
