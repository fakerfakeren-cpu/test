# Removes the nearest Mimas build and restores what was there before (same session).
execute unless entity @e[type=marker,tag=mimas_origin] run tellraw @s {text:"[Mimas] No build found nearby (stand near it).",color:"red"}
execute as @e[type=marker,tag=mimas_origin,sort=nearest,limit=1] at @s align xyz run function mimas:internal/clear_here
